from cupy import _core


bitwise_and = _core.bitwise_and


bitwise_or = _core.bitwise_or


bitwise_xor = _core.bitwise_xor


bitwise_not = _core.invert


invert = _core.invert


left_shift = _core.left_shift


right_shift = _core.right_shift
