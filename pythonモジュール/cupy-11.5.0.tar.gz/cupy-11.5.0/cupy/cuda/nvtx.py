from cupy_backends.cuda.libs.nvtx import *  # NOQA
