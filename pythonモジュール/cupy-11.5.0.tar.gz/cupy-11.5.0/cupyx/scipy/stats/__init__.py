from cupyx.scipy.stats._distributions import entropy  # NOQA
from cupyx.scipy.stats._stats import trim_mean  # NOQA
