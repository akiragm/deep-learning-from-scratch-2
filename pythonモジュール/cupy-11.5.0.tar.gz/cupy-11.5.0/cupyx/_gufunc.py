import cupy


class GeneralizedUFunc(cupy._core._gufuncs._GUFunc):
    __doc__ = cupy._core._gufuncs._GUFunc.__doc__
