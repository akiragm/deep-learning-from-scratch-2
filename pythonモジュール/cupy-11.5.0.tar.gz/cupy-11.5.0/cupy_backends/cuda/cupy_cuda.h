#ifndef INCLUDE_GUARD_CUDA_CUPY_CUDA_H
#define INCLUDE_GUARD_CUDA_CUPY_CUDA_H

#include <cuda.h>
#include <cuda_runtime.h>

#endif // #ifndef INCLUDE_GUARD_CUDA_CUPY_CUDA_H
