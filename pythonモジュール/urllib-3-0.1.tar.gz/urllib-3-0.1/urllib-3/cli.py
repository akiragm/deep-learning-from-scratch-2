def cli():
    pass


if __name__ == "__main__":
    try:
        cli()
    except KeyboardInterrupt:
        print("Exiting due to KeyboardInterrupt...")
